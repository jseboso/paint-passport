# Paint Passport — cloud backend

This adds two things to the project, both serverless (no servers, no Kubernetes):

- **Device → browser**: the ESP32 uploads a finished painting straight to S3 via a
  presigned URL; a small static web page lists everything in a gallery.
- **Browser → device**: you upload a photo on the web page; a container-image Lambda
  (Pillow) resizes/crops it to your device's 480×600 canvas and writes a raw 24-bit
  BMP in the same byte layout `firmware/esp32_client/media.cpp` already reads. The
  device polls a small "inbox" endpoint and picks it up next time it checks in.

Everything is defined as code in `infra/` (AWS CDK, TypeScript) — nothing was deployed
from the cloud sandbox that generated this, because that environment's outbound network
is locked down and can't reach npm, PyPI, or any AWS endpoint. You'll run the actual
`npm install` / `cdk deploy` commands yourself, from a normal terminal on this machine,
which does have internet access. Everything below assumes you're doing that here in the
`paint-passport` repo.

## 0. One-time prerequisites

- **Node.js 20+** — https://nodejs.org (LTS)
- **Docker Desktop** — required because `convert-inbox-image` deploys as a container
  image; `cdk deploy` builds it locally and needs a running Docker daemon.
- **An AWS account** with billing set up. If you don't have one yet: sign up at
  https://aws.amazon.com, then immediately go to **Billing → Budgets** and set a
  small budget alert (e.g. $5) so you get an email if anything runs away. At the
  traffic this project will see, actual cost should be a few cents a month at most.
- **An IAM user for deploying**, not your root account:
  1. AWS Console → IAM → Users → Create user (e.g. `paint-passport-deployer`).
  2. Attach policy `AdministratorAccess` for now — CDK needs broad permissions to
     create S3/Lambda/DynamoDB/IAM/API Gateway resources. Once things are stable you
     can tighten this to a scoped policy; for a personal project it's fine to relax
     later rather than fight IAM policies on day one.
  3. Security credentials tab → Create access key → "Command Line Interface (CLI)".
  4. Copy the Access Key ID and Secret Access Key somewhere safe — the secret is only
     shown once.
- **AWS CLI v2** — https://docs.aws.amazon.com/cli/latest/userguide/getting-started-install.html
  Then run:
  ```
  aws configure
  ```
  and paste in the access key, secret, a default region (e.g. `us-east-1`), and output
  format `json`.

## 1. Configure secrets (never committed)

```
cd infra
cp config.example.json config.json
```

Edit `config.json` and replace the placeholder strings with real random secrets — one
per device, plus one for the web upload form. Easy way to generate one:

```
openssl rand -hex 32
```

`config.json` is gitignored on purpose. Don't put real secrets in `config.example.json`.

## 2. Install and deploy

```
cd infra
npm install
npx cdk bootstrap        # one-time per AWS account + region
npx cdk synth             # sanity check — renders the CloudFormation template, deploys nothing
npx cdk deploy
```

`cdk deploy` will print a diff of what it's about to create and ask to confirm (IAM
changes always require confirmation). It'll build the Docker image for the conversion
Lambda, push it to a CDK-managed ECR repo, and create everything else. Takes a few
minutes the first time.

At the end you'll see outputs like:

```
PaintPassportStack.ApiUrl = https://abc123xyz.execute-api.us-east-1.amazonaws.com
PaintPassportStack.WebUrl = http://paintpassportstack-webbucket....s3-website-us-east-1.amazonaws.com
PaintPassportStack.MediaBucketName = paintpassportstack-mediabucket-...
```

## 3. Point the web page at your API

```
cd ../web
cp config.example.js config.js   # if you haven't already
```

Edit `config.js` and set `apiUrl` to the `ApiUrl` output above. Then redeploy so the
updated site gets uploaded:

```
cd ../infra
npx cdk deploy
```

Open the `WebUrl` output in a browser. The gallery will say "No paintings yet" until a
device uploads something — that's expected.

## 4. Try it without any firmware changes yet

You can exercise the whole device-upload path with `curl` before touching the ESP32
code, using one of the device keys from `config.json`:

```
curl -X POST "$API_URL/devices/device-1/paintings/presign" \
  -H "x-device-key: <the device-1 secret from config.json>"
```

That returns `{"uploadUrl": "...", "paintingId": "...", "key": "..."}`. PUT any BMP
file to `uploadUrl` and refresh the gallery page — it should show up within a second or
two (the `on-painting-uploaded` Lambda fires off the S3 event).

## 5. Firmware side

Implemented in `firmware/esp32_client/cloud.h` / `cloud.cpp`, wired into `esp32_client.ino`
and a couple of small additions to `media.h`/`media.cpp`/`config.h`. Summary of how it works:

**Uploading a painting** (device → cloud): `cloudUploadPainting(index)` is called right
after `savePainting()` succeeds (see the media-save touch handler in `esp32_client.ino`).
It POSTs to `/devices/{deviceId}/paintings/presign` with header `x-device-key`, then
streams the BMP straight from the SD card to the returned presigned S3 URL via
`HTTPClient::sendRequest("PUT", &file, size)` — no need to buffer the ~850KB image in RAM.
Blocking, same as the SD write itself; the SAVE button briefly shows "..." while it runs.

**Receiving an image** (cloud → device): `cloudTick()`, called every `loop()` iteration,
polls `/devices/{deviceId}/inbox` roughly every 30s — but only when the device is idle
(`appMode == MODE_PAINT`, no panel open, no stroke in progress), so it never interrupts
active use. When something's waiting, it streams the BMP to a new `/paintings/NNN.bmp` on
SD, generates its thumbnail, and adds it to the media gallery — **it does not touch the
live canvas**, so it can never overwrite a painting in progress. You open a received image
from the Media panel whenever you want, exactly like any other saved painting. After a
successful download it POSTs to `/devices/{deviceId}/inbox/ack`.

**Setup**, in `firmware/esp32_client/`:
```
cp cloud_secrets.example.h cloud_secrets.h
```
Edit `cloud_secrets.h` and fill in `CLOUD_API_BASE` (the `ApiUrl` output), `CLOUD_DEVICE_ID`,
and `CLOUD_DEVICE_KEY` (matching one of the entries under `deviceKeys` in `infra/config.json`).
`cloud_secrets.h` is gitignored — if you flash a second device, give it its own device ID/key
pair from `config.json` rather than reusing the first one's.

No new libraries to install — everything used (`WiFiClientSecure`, `HTTPClient`, `SD`) ships
with the ESP32 board package you already have. TLS certificate validation is skipped
(`setInsecure()`) rather than pinning a root CA — see the comment in
`cloud_secrets.example.h` for the tradeoff.

I couldn't compile-test any of this firmware (no Arduino toolchain in the sandbox that
generated it) — if the first build throws an error, paste it back and I'll fix it fast.

## 6. Cost and cleanup

Everything here is pay-per-use serverless (S3, Lambda, DynamoDB on-demand, API Gateway
HTTP API) — at personal-project traffic this is pennies a month, and DynamoDB/Lambda
both have permanent free tiers. If you ever want to tear it all down:

```
cd infra
npx cdk destroy
```

Note: `MediaBucket`, `PaintingsTable`, and `InboxTable` are set to `RETAIN` on stack
deletion (so `cdk destroy` won't accidentally delete your paintings) — you'd need to
delete those manually from the console afterward if you actually want them gone.
