#pragma once
#include <stdint.h>
#include <stddef.h>

// Talks to the AWS backend described in ../../CLOUD_README.md:
//   - cloudUploadPainting(): device -> S3 -> web gallery
//   - cloudTick(): polls the device's cloud "inbox" for images sent from the
//     web page, and drops anything new straight into the SD media gallery.
//     It does NOT touch the live canvas, so it can never overwrite a
//     painting in progress - open a received image from the Media panel
//     whenever you want, same as any other saved painting.

void cloudInit();
void cloudTick();

// Uploads /paintings/{paintingIndex}.bmp to the cloud gallery. Blocking -
// call this right after savePainting() succeeds; the whole operation takes
// a moment, the same way the SD write itself does.
bool cloudUploadPainting(uint8_t paintingIndex);
