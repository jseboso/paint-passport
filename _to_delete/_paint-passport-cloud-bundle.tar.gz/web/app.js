const cfg = window.APP_CONFIG || {};

function apiUrl(pathname) {
  return cfg.apiUrl.replace(/\/$/, '') + pathname;
}

async function loadGallery() {
  const gallery = document.getElementById('gallery');

  if (!cfg.apiUrl || cfg.apiUrl.includes('REPLACE-ME')) {
    gallery.textContent = 'Set apiUrl in web/config.js (copy it from config.example.js) and redeploy.';
    return;
  }

  const deviceId = document.getElementById('filter-device').value.trim();
  const url = new URL(apiUrl('/paintings'));
  if (deviceId) url.searchParams.set('deviceId', deviceId);

  gallery.textContent = 'Loading...';

  try {
    const res = await fetch(url);
    const data = await res.json();
    gallery.innerHTML = '';

    if (!data.paintings || data.paintings.length === 0) {
      gallery.textContent = 'No paintings yet.';
      return;
    }

    for (const p of data.paintings) {
      const card = document.createElement('div');
      card.className = 'card';

      const img = document.createElement('img');
      img.src = p.url;
      img.alt = `${p.deviceId} / ${p.paintingId}`;

      const caption = document.createElement('p');
      caption.textContent = `${p.deviceId} — ${new Date(p.createdAt).toLocaleString()}`;

      card.appendChild(img);
      card.appendChild(caption);
      gallery.appendChild(card);
    }
  } catch (err) {
    gallery.textContent = 'Failed to load gallery: ' + err.message;
  }
}

document.getElementById('refresh-btn').addEventListener('click', loadGallery);

document.getElementById('send-form').addEventListener('submit', async (e) => {
  e.preventDefault();
  const statusEl = document.getElementById('send-status');
  const deviceId = document.getElementById('device-id').value.trim();
  const webKey = document.getElementById('web-key').value;
  const file = document.getElementById('image-file').files[0];

  if (!deviceId || !webKey || !file) return;

  statusEl.textContent = 'Requesting upload URL...';
  try {
    const presignRes = await fetch(
      apiUrl(`/devices/${encodeURIComponent(deviceId)}/inbox/presign?contentType=${encodeURIComponent(file.type)}`),
      { method: 'POST', headers: { 'x-web-key': webKey } },
    );
    if (!presignRes.ok) {
      const errBody = await presignRes.json().catch(() => ({}));
      throw new Error(errBody.error || `presign failed (${presignRes.status})`);
    }
    const { uploadUrl } = await presignRes.json();

    statusEl.textContent = 'Uploading...';
    const putRes = await fetch(uploadUrl, {
      method: 'PUT',
      headers: { 'Content-Type': file.type },
      body: file,
    });
    if (!putRes.ok) throw new Error(`upload failed (${putRes.status})`);

    statusEl.textContent = 'Sent! The device will pick it up next time it polls its inbox.';
  } catch (err) {
    statusEl.textContent = 'Error: ' + err.message;
  }
});

loadGallery();
